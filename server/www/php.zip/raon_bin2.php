<!DOCTYPE html>
<html>
<body>

<?php
	echo "안녕하세요 라온하제 팀입니다";
	echo "<br/>\n"; // 줄 개행
	echo "데이터를 주고받을 사이트 입니다";
?>

</body>
</html>
